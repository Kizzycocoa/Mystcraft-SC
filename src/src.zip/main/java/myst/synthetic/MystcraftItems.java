package myst.synthetic;

import java.util.function.Function;

import myst.synthetic.item.ItemWritingDeskTop;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorType;
import myst.synthetic.item.ItemLinkbook;
import myst.synthetic.item.ItemUnlinkedLinkbook;

public class MystcraftItems {

    public static <T extends Item> T register(String name, Function<Item.Properties, T> itemFactory, Item.Properties settings) {
        ResourceKey<Item> itemKey = ResourceKey.create(
                Registries.ITEM,
                Identifier.fromNamespaceAndPath("mystcraft-sc", name)
        );

        T item = itemFactory.apply(settings.setId(itemKey));
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        return item;
    }

    public static final Item AGEBOOK = register("agebook", Item::new, new Item.Properties());
    public static final Item LINKBOOK = register("linkbook", ItemLinkbook::new, new Item.Properties());
    public static final Item UNLINKEDBOOK = register("unlinkedbook", ItemUnlinkedLinkbook::new, new Item.Properties());
    public static final Item BOOSTER = register("booster", Item::new, new Item.Properties());
    public static final Item FOLDER = register("folder", Item::new, new Item.Properties());
    public static final Item PORTFOLIO = register("portfolio", Item::new, new Item.Properties());
    public static final Item VIAL = register("vial", Item::new, new Item.Properties().stacksTo(16));
    
    public static final Item GLASSES = register(
            "glasses",
            Item::new,
            new Item.Properties().humanoidArmor(MystcraftArmorMaterials.GLASSES, ArmorType.HELMET).stacksTo(1)
    );

    public static final Item WRITING_DESK_TOP = register(
            "writingdesk_top",
            ItemWritingDeskTop::new,
            new Item.Properties()
    );

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(LINKBOOK);
        });

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(GLASSES);
        });
    }
}