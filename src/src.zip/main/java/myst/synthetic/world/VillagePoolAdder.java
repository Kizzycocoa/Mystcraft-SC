package myst.synthetic.worldgen;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.levelgen.structure.pools.SinglePoolElement;
import net.minecraft.world.level.levelgen.structure.pools.StructurePoolElement;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;

public final class VillagePoolAdder {

    private VillagePoolAdder() {}

    public static void inject(MinecraftServer server) {

        add(server,
                "village/plains/houses",
                "mystcraft-sc:village/plains/houses/plains_atelier_1",
                6
        );

        add(server,
                "village/plains/houses",
                "mystcraft-sc:village/plains/houses/plains_atelier_2",
                6
        );

        add(server,
                "village/desert/houses",
                "mystcraft-sc:village/desert/houses/desert_atelier_1",
                6
        );

        add(server,
                "village/desert/houses",
                "mystcraft-sc:village/desert/houses/desert_atelier_2",
                6
        );

        add(server,
                "village/savanna/houses",
                "mystcraft-sc:village/savanna/houses/savanna_atelier_1",
                6
        );

        add(server,
                "village/savanna/houses",
                "mystcraft-sc:village/savanna/houses/savanna_atelier_2",
                6
        );

        add(server,
                "village/snowy/houses",
                "mystcraft-sc:village/snowy/houses/snowy_atelier_1",
                6
        );

        add(server,
                "village/snowy/houses",
                "mystcraft-sc:village/snowy/houses/snowy_atelier_2",
                6
        );

        add(server,
                "village/taiga/houses",
                "mystcraft-sc:village/taiga/houses/taiga_atelier_1",
                6
        );

        add(server,
                "village/taiga/houses",
                "mystcraft-sc:village/taiga/houses/taiga_atelier_2",
                6
        );
    }


    private static void add(
            MinecraftServer server,
            String poolId,
            String structureId,
            int weight
    ) {

        StructureTemplatePool pool = server.registryAccess()
                .registryOrThrow(Registries.TEMPLATE_POOL)
                .get(ResourceLocation.withDefaultNamespace(poolId));

        if (pool == null) return;

        StructurePoolElement element =
                SinglePoolElement.legacy(structureId)
                        .apply(StructureTemplatePool.Projection.RIGID);

        pool.templates.add(element);

        pool.rawTemplates.add(Pair.of(element, weight));
    }
}