package myst.synthetic.menu;

import myst.synthetic.block.entity.DisplayBlockEntity;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class DisplayLecternMenu extends AbstractContainerMenu {

    public static final int BUTTON_PREV_PAGE = 1;
    public static final int BUTTON_NEXT_PAGE = 2;
    public static final int BUTTON_TAKE_BOOK = 3;
    public static final int BUTTON_PAGE_JUMP_RANGE_START = 100;

    private final Container container;
    private final ContainerData pageData;

    public DisplayLecternMenu(int id, Container container, ContainerData data) {
        super(null, id);

        this.container = container;
        this.pageData = data;

        this.addSlot(new Slot(container, 0, 0, 0));

        this.addDataSlots(data);
    }

    public DisplayLecternMenu(int id) {
        this(id, new SimpleContainer(1), new SimpleContainerData(1));
    }

    @Override
    public boolean clickMenuButton(Player player, int button) {

        if (button >= 100) {
            int page = button - 100;
            this.setData(0, page);
            return true;
        }

        switch (button) {

            case BUTTON_PREV_PAGE -> {
                this.setData(0, this.pageData.get(0) - 1);
                return true;
            }

            case BUTTON_NEXT_PAGE -> {
                this.setData(0, this.pageData.get(0) + 1);
                return true;
            }

            case BUTTON_TAKE_BOOK -> {

                ItemStack stack = this.container.removeItemNoUpdate(0);
                this.container.setChanged();

                if (!player.getInventory().add(stack)) {
                    player.drop(stack, false);
                }

                return true;
            }

            default -> {
                return false;
            }
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    public ItemStack getBook() {
        return this.container.getItem(0);
    }

    public int getPage() {
        return this.pageData.get(0);
    }
}