package myst.synthetic.util;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import myst.synthetic.MystcraftBlocks;
import myst.synthetic.block.BlockBookReceptacle;
import myst.synthetic.block.BlockCrystal;
import myst.synthetic.block.BlockLinkPortal;
import myst.synthetic.block.entity.BlockEntityBookReceptacle;
import myst.synthetic.block.property.CrystalColor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public final class PortalUtils {

    private PortalUtils() {
    }

    public static void firePortal(Level level, BlockPos receptaclePos, CrystalColor requiredColor) {
        BlockEntity be = level.getBlockEntity(receptaclePos);
        if (!(be instanceof BlockEntityBookReceptacle receptacle)) {
            return;
        }

        if (!receptacle.hasValidPortalBook()) {
            return;
        }

        if (!receptacle.hasValidSupportCrystal()) {
            return;
        }

        BlockPos basePos = receptacle.getSupportCrystalPos();
        BlockState baseState = level.getBlockState(basePos);

        if (!baseState.is(MystcraftBlocks.CRYSTAL)) {
            return;
        }

        if (baseState.getValue(BlockCrystal.COLOR) != requiredColor) {
            return;
        }

        depolarizeFrom(level, basePos, requiredColor);
        pathCrystalNetwork(level, receptaclePos, basePos, requiredColor);

        // Next step:
        // detect valid frames attached to the active network
        // fill them with directed link portal blocks
    }

    public static void shutdownPortal(Level level, BlockPos receptaclePos) {
        BlockEntity be = level.getBlockEntity(receptaclePos);
        if (!(be instanceof BlockEntityBookReceptacle receptacle)) {
            return;
        }

        if (!receptacle.hasValidSupportCrystal()) {
            return;
        }

        BlockPos basePos = receptacle.getSupportCrystalPos();
        CrystalColor requiredColor = receptacle.getBlockState().getValue(BlockBookReceptacle.COLOR);

        depolarizeFrom(level, basePos, requiredColor);
    }

    private static void pathCrystalNetwork(Level level, BlockPos receptaclePos, BlockPos basePos, CrystalColor requiredColor) {
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();
        Map<BlockPos, BlockPos> parentByPos = new HashMap<>();

        queue.add(basePos);
        parentByPos.put(basePos, receptaclePos);

        while (!queue.isEmpty()) {
            BlockPos pos = queue.removeFirst();
            if (!visited.add(pos)) {
                continue;
            }

            BlockState state = level.getBlockState(pos);
            if (!state.is(MystcraftBlocks.CRYSTAL)) {
                continue;
            }

            if (state.getValue(BlockCrystal.COLOR) != requiredColor) {
                continue;
            }

            BlockPos parentPos = parentByPos.get(pos);
            if (parentPos == null) {
                continue;
            }

            Direction sourceDirection = directionFromTo(pos, parentPos);

            level.setBlock(
                    pos,
                    BlockCrystal.getDirectedState(state, sourceDirection),
                    Block.UPDATE_ALL
            );

            for (Direction direction : Direction.values()) {
                BlockPos neighborPos = pos.relative(direction);

                if (visited.contains(neighborPos) || parentByPos.containsKey(neighborPos)) {
                    continue;
                }

                BlockState neighborState = level.getBlockState(neighborPos);
                if (!neighborState.is(MystcraftBlocks.CRYSTAL)) {
                    continue;
                }

                if (neighborState.getValue(BlockCrystal.COLOR) != requiredColor) {
                    continue;
                }

                parentByPos.put(neighborPos, pos);
                queue.add(neighborPos);
            }
        }
    }

    public static void depolarizeFrom(Level level, BlockPos startPos, CrystalColor requiredColor) {
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();

        queue.add(startPos);

        while (!queue.isEmpty()) {
            BlockPos pos = queue.removeFirst();
            if (!visited.add(pos)) {
                continue;
            }

            BlockState state = level.getBlockState(pos);

            if (state.is(MystcraftBlocks.CRYSTAL)) {
                if (state.getValue(BlockCrystal.COLOR) != requiredColor || !state.getValue(BlockCrystal.ACTIVE)) {
                    continue;
                }

                level.setBlock(pos, BlockCrystal.getDisabledState(state), Block.UPDATE_ALL);
                addSameColorNeighbors(level, pos, requiredColor, queue, visited);
                continue;
            }

            if (state.is(MystcraftBlocks.LINK_PORTAL)) {
                if (state.getValue(BlockLinkPortal.COLOR) != requiredColor || !state.getValue(BlockLinkPortal.ACTIVE)) {
                    continue;
                }

                level.removeBlock(pos, false);
                addSameColorNeighbors(level, pos, requiredColor, queue, visited);
            }
        }
    }

    public static void validatePortal(Level level, BlockPos portalPos) {
        BlockState state = level.getBlockState(portalPos);
        if (!state.is(MystcraftBlocks.LINK_PORTAL)) {
            return;
        }

        if (!state.getValue(BlockLinkPortal.ACTIVE)) {
            level.removeBlock(portalPos, false);
            return;
        }

        CrystalColor requiredColor = state.getValue(BlockLinkPortal.COLOR);
        Direction sourceDirection = state.getValue(BlockLinkPortal.SOURCE_DIRECTION);
        BlockPos sourcePos = portalPos.relative(sourceDirection);
        BlockState sourceState = level.getBlockState(sourcePos);

        if (sourceState.is(MystcraftBlocks.CRYSTAL)) {
            if (!sourceState.getValue(BlockCrystal.ACTIVE)
                    || sourceState.getValue(BlockCrystal.COLOR) != requiredColor) {
                level.removeBlock(portalPos, false);
            }
            return;
        }

        if (sourceState.is(MystcraftBlocks.LINK_PORTAL)) {
            if (!sourceState.getValue(BlockLinkPortal.ACTIVE)
                    || sourceState.getValue(BlockLinkPortal.COLOR) != requiredColor) {
                level.removeBlock(portalPos, false);
            }
            return;
        }

        if (getOwningReceptacle(level, portalPos) == null) {
            level.removeBlock(portalPos, false);
        }
    }

    public static boolean isCrystalStillValid(Level level, BlockPos pos, CrystalColor requiredColor) {
        BlockState state = level.getBlockState(pos);
        if (!state.is(MystcraftBlocks.CRYSTAL) || !state.getValue(BlockCrystal.ACTIVE)) {
            return false;
        }

        if (state.getValue(BlockCrystal.COLOR) != requiredColor) {
            return false;
        }

        Direction sourceDirection = state.getValue(BlockCrystal.SOURCE_DIRECTION);
        BlockPos sourcePos = pos.relative(sourceDirection);
        BlockState sourceState = level.getBlockState(sourcePos);

        if (sourceState.is(MystcraftBlocks.CRYSTAL)) {
            return sourceState.getValue(BlockCrystal.ACTIVE)
                    && sourceState.getValue(BlockCrystal.COLOR) == requiredColor;
        }

        if (sourceState.is(MystcraftBlocks.LINK_PORTAL)) {
            return sourceState.getValue(BlockLinkPortal.ACTIVE)
                    && sourceState.getValue(BlockLinkPortal.COLOR) == requiredColor;
        }

        BlockEntity be = level.getBlockEntity(sourcePos);
        if (be instanceof BlockEntityBookReceptacle receptacle) {
            return receptacle.hasValidPortalBook()
                    && receptacle.hasValidSupportCrystal()
                    && receptacle.getBlockState().getValue(BlockBookReceptacle.COLOR) == requiredColor
                    && receptacle.getSupportCrystalPos().equals(pos);
        }

        return false;
    }

    public static void validateAround(Level level, BlockPos origin, CrystalColor requiredColor) {
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = origin.relative(direction);
            BlockState neighborState = level.getBlockState(neighborPos);

            if (neighborState.is(MystcraftBlocks.LINK_PORTAL)
                    && neighborState.getValue(BlockLinkPortal.COLOR) == requiredColor) {
                validatePortal(level, neighborPos);
            } else if (neighborState.is(MystcraftBlocks.CRYSTAL)
                    && neighborState.getValue(BlockCrystal.COLOR) == requiredColor
                    && neighborState.getValue(BlockCrystal.ACTIVE)
                    && !isCrystalStillValid(level, neighborPos, requiredColor)) {
                level.setBlock(neighborPos, BlockCrystal.getDisabledState(neighborState), Block.UPDATE_ALL);
            }
        }
    }

    public static BlockEntityBookReceptacle getOwningReceptacle(Level level, BlockPos startPos) {
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();

        queue.add(startPos);

        while (!queue.isEmpty()) {
            BlockPos pos = queue.removeFirst();
            if (!visited.add(pos)) {
                continue;
            }

            BlockState state = level.getBlockState(pos);

            if (state.is(MystcraftBlocks.CRYSTAL) && state.getValue(BlockCrystal.ACTIVE)) {
                queue.add(pos.relative(state.getValue(BlockCrystal.SOURCE_DIRECTION)));
                continue;
            }

            if (state.is(MystcraftBlocks.LINK_PORTAL) && state.getValue(BlockLinkPortal.ACTIVE)) {
                queue.add(pos.relative(state.getValue(BlockLinkPortal.SOURCE_DIRECTION)));
                continue;
            }

            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof BlockEntityBookReceptacle receptacle) {
                return receptacle;
            }
        }

        return null;
    }

    private static void addSameColorNeighbors(
            Level level,
            BlockPos pos,
            CrystalColor requiredColor,
            ArrayDeque<BlockPos> queue,
            Set<BlockPos> visited
    ) {
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = pos.relative(direction);
            if (visited.contains(neighborPos)) {
                continue;
            }

            BlockState neighborState = level.getBlockState(neighborPos);

            if (neighborState.is(MystcraftBlocks.CRYSTAL)
                    && neighborState.getValue(BlockCrystal.COLOR) == requiredColor
                    && neighborState.getValue(BlockCrystal.ACTIVE)) {
                queue.add(neighborPos);
                continue;
            }

            if (neighborState.is(MystcraftBlocks.LINK_PORTAL)
                    && neighborState.getValue(BlockLinkPortal.COLOR) == requiredColor
                    && neighborState.getValue(BlockLinkPortal.ACTIVE)) {
                queue.add(neighborPos);
            }
        }
    }

    public static Direction directionFromTo(BlockPos from, BlockPos to) {
        int dx = to.getX() - from.getX();
        int dy = to.getY() - from.getY();
        int dz = to.getZ() - from.getZ();

        if (dx == 1 && dy == 0 && dz == 0) {
            return Direction.EAST;
        }
        if (dx == -1 && dy == 0 && dz == 0) {
            return Direction.WEST;
        }
        if (dx == 0 && dy == 1 && dz == 0) {
            return Direction.UP;
        }
        if (dx == 0 && dy == -1 && dz == 0) {
            return Direction.DOWN;
        }
        if (dx == 0 && dy == 0 && dz == 1) {
            return Direction.SOUTH;
        }
        if (dx == 0 && dy == 0 && dz == -1) {
            return Direction.NORTH;
        }

        throw new IllegalArgumentException("Positions are not adjacent: " + from + " -> " + to);
    }
}