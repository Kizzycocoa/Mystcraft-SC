package myst.synthetic;

import myst.synthetic.config.MystcraftConfig;
import myst.synthetic.recipe.MystcraftRecipeSerializers;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import myst.synthetic.world.VillagePoolAdder;

public class MystcraftSyntheticCodex implements ModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("mystcraft-sc");

	@Override
	public void onInitialize() {
		MystcraftConfig.load();

		MystcraftBlocks.initialize();
		MystcraftEntities.initialize();
		MystcraftBlockEntities.initialize();
		MystcraftItems.initialize();
		MystcraftItemGroups.initialize();
		MystcraftRecipeSerializers.initialize();
		MystcraftNetworking.initialize();
		MystcraftPoiTypes.initialize();
		MystcraftVillagerProfessions.initialize();
		MystcraftVillagerTrades.initialize();

		BuiltInRegistries.REGISTRY.freeze();
		VillagePoolAdder.bootstrap(BuiltInRegistries.REGISTRY.asLookup());

		LOGGER.info("Mystcraft config directory: {}", MystcraftConfig.getConfigDir());
		LOGGER.info("Mystcraft: The Synthetic Codex initialized.");
	}
}