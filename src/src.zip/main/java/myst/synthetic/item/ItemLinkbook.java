package myst.synthetic.item;

import myst.synthetic.LinkBookClientBridge;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ItemLinkbook extends Item {

	public ItemLinkbook(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);

		if (level.isClientSide()) {
			LinkBookClientBridge.open(stack.copy());
		}

		return InteractionResult.SUCCESS;
	}
}