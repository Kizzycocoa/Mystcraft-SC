package myst.synthetic;

import myst.synthetic.block.entity.BlockEntityDisplayContainer;
import myst.synthetic.linking.LinkController;
import myst.synthetic.linking.LinkOptions;
import myst.synthetic.network.DisplayContainerExtractPayload;
import myst.synthetic.network.DisplayContainerInsertPayload;
import myst.synthetic.network.LinkBookUsePayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import myst.synthetic.item.BookBookmarkUtil;
import myst.synthetic.network.LinkBookBookmarkExtractPayload;

public final class MystcraftNetworking {

    private MystcraftNetworking() {
    }

    public static void initialize() {
        PayloadTypeRegistry.playC2S().register(LinkBookUsePayload.ID, LinkBookUsePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(DisplayContainerExtractPayload.ID, DisplayContainerExtractPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(DisplayContainerInsertPayload.ID, DisplayContainerInsertPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(LinkBookBookmarkExtractPayload.ID, LinkBookBookmarkExtractPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(LinkBookUsePayload.ID, (payload, context) -> {
            var player = context.player();

            context.server().execute(() -> {
                InteractionHand hand = payload.mainHand() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
                ItemStack stack = player.getItemInHand(hand);

                if (!stack.is(MystcraftItems.LINKBOOK)) {
                    return;
                }

                CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
                if (customData == null) {
                    return;
                }

                CompoundTag tag = customData.copyTag();
                LinkOptions info = new LinkOptions(tag);

                String targetDimension = info.getDimensionUID();
                if (targetDimension == null || targetDimension.isBlank()) {
                    return;
                }

                String currentDimension = extractDimensionId(player.level().dimension().toString());

                if (currentDimension.equals(targetDimension)) {
                    return;
                }

                LinkController.travelEntity(player.level(), player, info);
            });
        });
        ServerPlayNetworking.registerGlobalReceiver(LinkBookBookmarkExtractPayload.ID, (payload, context) -> {
            var player = context.player();

            context.server().execute(() -> {
                InteractionHand hand = payload.mainHand() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
                ItemStack stack = player.getItemInHand(hand);

                if (!stack.is(MystcraftItems.LINKBOOK) && !stack.is(MystcraftItems.AGEBOOK)) {
                    return;
                }

                ItemStack removed = BookBookmarkUtil.removeBookmark(stack);
                if (removed.isEmpty()) {
                    return;
                }

                if (!player.getInventory().add(removed)) {
                    player.drop(removed, false);
                }

                player.inventoryMenu.broadcastChanges();
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(DisplayContainerExtractPayload.ID, (payload, context) -> {
            var player = context.player();

            context.server().execute(() -> {
                if (!(player.level().getBlockEntity(payload.pos()) instanceof BlockEntityDisplayContainer blockEntity)) {
                    return;
                }

                if (!player.blockPosition().closerThan(payload.pos(), 8.0D)) {
                    return;
                }

                if (!blockEntity.hasStoredItem()) {
                    return;
                }

                ItemStack removed = blockEntity.takeStoredItem();
                if (removed.isEmpty()) {
                    return;
                }

                if (player.getMainHandItem().isEmpty()) {
                    player.setItemInHand(InteractionHand.MAIN_HAND, removed);
                } else if (!player.addItem(removed)) {
                    player.drop(removed, false);
                }

                player.inventoryMenu.broadcastChanges();
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(DisplayContainerInsertPayload.ID, (payload, context) -> {
            var player = context.player();

            context.server().execute(() -> {
                if (!(player.level().getBlockEntity(payload.pos()) instanceof BlockEntityDisplayContainer blockEntity)) {
                    return;
                }

                if (!player.blockPosition().closerThan(payload.pos(), 8.0D)) {
                    return;
                }

                int slot = payload.playerSlot();
                if (slot < 0 || slot >= Inventory.getSelectionSize() + 27) {
                    return;
                }

                Inventory inventory = player.getInventory();
                ItemStack clicked = inventory.getItem(slot);

                if (clicked.isEmpty()) {
                    return;
                }

                if (!blockEntity.canAcceptDisplayItem(clicked)) {
                    return;
                }

                ItemStack previous = ItemStack.EMPTY;
                if (blockEntity.hasStoredItem()) {
                    previous = blockEntity.takeStoredItem();
                }

                blockEntity.setStoredItem(clicked.copyWithCount(1));

                if (!player.getAbilities().instabuild) {
                    clicked.shrink(1);
                    inventory.setItem(slot, clicked);
                }

                if (!previous.isEmpty()) {
                    if (!player.addItem(previous)) {
                        player.drop(previous, false);
                    }
                }

                player.inventoryMenu.broadcastChanges();
            });
        });
    }

    private static String extractDimensionId(String raw) {
        int slash = raw.lastIndexOf('/');
        int end = raw.lastIndexOf(']');

        if (slash >= 0 && end > slash) {
            return raw.substring(slash + 1, end).trim();
        }

        return raw;
    }
}