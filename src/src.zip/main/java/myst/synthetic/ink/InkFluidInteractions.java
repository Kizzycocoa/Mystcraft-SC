package myst.synthetic.ink;

import myst.synthetic.MystcraftFluids;
import myst.synthetic.MystcraftItems;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;

public final class InkFluidInteractions {

    private InkFluidInteractions() {
    }

    public static void initialize() {

        UseItemCallback.EVENT.register((player, level, hand) -> {

            ItemStack held = player.getItemInHand(hand);

            if (!held.is(Items.GLASS_BOTTLE)) {
                return InteractionResult.PASS;
            }

            BlockHitResult hit = Item.getPlayerPOVHitResult(
                    level,
                    player,
                    ClipContext.Fluid.SOURCE_ONLY
            );

            if (hit.getType() != BlockHitResult.Type.BLOCK) {
                return InteractionResult.PASS;
            }

            BlockPos pos = hit.getBlockPos();

            FluidState fluidState = level.getFluidState(pos);

            if (!fluidState.is(MystcraftFluids.BLACK_INK)
                    || !fluidState.isSource()) {
                return InteractionResult.PASS;
            }

            if (!level.isClientSide()) {

                ItemStack vial = new ItemStack(MystcraftItems.VIAL);

                if (!player.getAbilities().instabuild) {

                    held.shrink(1);

                    if (held.isEmpty()) {
                        player.setItemInHand(hand, vial);
                    } else if (!player.getInventory().add(vial)) {
                        player.drop(vial, false);
                    }
                }

                level.setBlock(pos, Blocks.AIR.defaultBlockState(), 11);

                level.playSound(
                        null,
                        pos,
                        SoundEvents.BOTTLE_FILL,
                        SoundSource.BLOCKS,
                        1.0F,
                        1.0F
                );
            }

            return InteractionResult.SUCCESS;
        });
    }
}