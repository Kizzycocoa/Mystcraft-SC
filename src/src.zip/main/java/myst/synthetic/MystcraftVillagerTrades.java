package myst.synthetic;

import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.VillagerTrades;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import org.jetbrains.annotations.Nullable;

public final class MystcraftVillagerTrades {

    private static final float PRICE_MULTIPLIER = 0.05f;

    private MystcraftVillagerTrades() {
    }

    public static void initialize() {
        registerLevel1();
        registerLevel2();
        registerLevel3();
        registerLevel4();
        registerLevel5();
    }

    private static void registerLevel1() {
        TradeOfferHelper.registerVillagerOffers(MystcraftVillagerProfessions.ARCHIVIST, 1, factories -> {
            /*
             * IN TIME:
             * 1 common page
             * costs 8 emeralds
             * 5 trade stock
             * 3 villager experience
             * 0.05 price multiplier
             * Do this trade twice
             *
             * factories.add(pageForEmeralds(CommonPagePools::randomPage, 8, 5, 3, PRICE_MULTIPLIER));
             * factories.add(pageForEmeralds(CommonPagePools::randomPage, 8, 5, 3, PRICE_MULTIPLIER));
             */

            // FOR NOW: librarian-style paper buy
            factories.add(new VillagerTrades.EmeraldForItems(
                    Items.PAPER,
                    24,
                    16,
                    2,
                    PRICE_MULTIPLIER
            ));
        });
    }

    private static void registerLevel2() {
        TradeOfferHelper.registerVillagerOffers(MystcraftVillagerProfessions.ARCHIVIST, 2, factories -> {
            /*
             * IN TIME:
             * 1 uncommon page
             * costs 16 emeralds
             * 5 trade stock
             * 5 villager experience
             * 0.05 price multiplier
             *
             * factories.add(pageForEmeralds(UncommonPagePools::randomPage, 16, 5, 5, PRICE_MULTIPLIER));
             */

            // FOR NOW: 1 ink bottle for 5 emeralds
            factories.add(itemsForEmeralds(
                    MystcraftItems.VIAL,
                    1,
                    5,
                    5,
                    5,
                    PRICE_MULTIPLIER
            ));
        });
    }

    private static void registerLevel3() {
        TradeOfferHelper.registerVillagerOffers(MystcraftVillagerProfessions.ARCHIVIST, 3, factories -> {
            /*
             * IN TIME:
             * 1 rare page
             * costs 25 emeralds
             * 5 trade stock
             * 8 villager experience
             * 0.05 price multiplier
             *
             * factories.add(pageForEmeralds(RarePagePools::randomPage, 25, 5, 8, PRICE_MULTIPLIER));
             */

            // FOR NOW: 2 crystal blocks for 16 emeralds
            factories.add(itemsForEmeralds(
                    MystcraftBlocks.CRYSTAL.asItem(),
                    2,
                    16,
                    10,
                    8,
                    PRICE_MULTIPLIER
            ));
        });
    }

    private static void registerLevel4() {
        TradeOfferHelper.registerVillagerOffers(MystcraftVillagerProfessions.ARCHIVIST, 4, factories -> {
            /*
             * IN TIME:
             * 1 legendary page
             * costs 35 emeralds
             * 5 trade stock
             * 10 villager experience
             * 0.05 price multiplier
             *
             * factories.add(pageForEmeralds(LegendaryPagePools::randomPage, 35, 5, 10, PRICE_MULTIPLIER));
             */

            // FOR NOW: 1 unlinked linking book for 32 emeralds
            factories.add(itemsForEmeralds(
                    MystcraftItems.UNLINKEDBOOK,
                    1,
                    32,
                    2,
                    12,
                    PRICE_MULTIPLIER
            ));
        });
    }

    private static void registerLevel5() {
        TradeOfferHelper.registerVillagerOffers(MystcraftVillagerProfessions.ARCHIVIST, 5, factories -> {
            /*
             * IN TIME:
             * 1 Bahro Leather
             * costs 40 emeralds
             * 2 trade stock
             * 10 villager experience
             * 0.05 price multiplier
             *
             * factories.add(itemsForEmeralds(MystcraftItems.BAHRO_LEATHER, 1, 40, 2, 10, PRICE_MULTIPLIER));
             */

            // FOR NOW: 1 booster pack for 20 emeralds
            factories.add(itemsForEmeralds(
                    MystcraftItems.BOOSTER,
                    1,
                    20,
                    5,
                    20,
                    PRICE_MULTIPLIER
            ));
        });
    }

    /**
     * Helper for villager sells item-for-emeralds trades.
     */
    private static VillagerTrades.ItemListing itemsForEmeralds(
            Item item,
            int itemCount,
            int emeraldCost,
            int maxUses,
            int villagerXp,
            float priceMultiplier
    ) {
        return (entity, random) -> new MerchantOffer(
                new ItemCost(Items.EMERALD, emeraldCost),
                new ItemStack(item, itemCount),
                maxUses,
                villagerXp,
                priceMultiplier
        );
    }

    /**
     * IN TIME helper for page trades.
     * Leave this commented until page data/components are in.
     */
    /*
    private static TradeOffers.ItemListing pageForEmeralds(
            java.util.function.Supplier<ItemStack> pageSupplier,
            int emeraldCost,
            int maxUses,
            int villagerXp,
            float priceMultiplier
    ) {
        return (entity, random) -> new net.minecraft.world.item.trading.MerchantOffer(
                new net.minecraft.world.item.trading.ItemCost(Items.EMERALD, emeraldCost),
                pageSupplier.get(),
                maxUses,
                villagerXp,
                priceMultiplier
        );
    }
    */
}