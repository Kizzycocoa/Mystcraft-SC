package myst.synthetic.client.screen;

import myst.synthetic.menu.DisplayLecternMenu;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.client.gui.screens.inventory.MenuAccess;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerListener;
import net.minecraft.world.item.ItemStack;

public class DisplayLecternScreen extends BookViewScreen implements MenuAccess<DisplayLecternMenu> {

    private static final Component TAKE_BOOK =
            Component.translatable("lectern.take_book");

    private final DisplayLecternMenu menu;

    private final ContainerListener listener = new ContainerListener() {

        @Override
        public void slotChanged(AbstractContainerMenu menu, int slot, ItemStack stack) {
            DisplayLecternScreen.this.bookChanged();
        }

        @Override
        public void dataChanged(AbstractContainerMenu menu, int index, int value) {
            if (index == 0) {
                DisplayLecternScreen.this.pageChanged();
            }
        }
    };

    public DisplayLecternScreen(DisplayLecternMenu menu) {

        super(BookAccess.EMPTY_ACCESS);

        this.menu = menu;
    }

    @Override
    public DisplayLecternMenu getMenu() {
        return menu;
    }

    @Override
    protected void init() {

        super.init();

        menu.addSlotListener(listener);

        this.bookChanged();
    }

    @Override
    public void removed() {

        super.removed();

        menu.removeSlotListener(listener);
    }

    @Override
    protected void createMenuControls() {

        int y = this.menuControlsTop();
        int center = this.width / 2;

        this.addRenderableWidget(
                net.minecraft.client.gui.components.Button.builder(
                        CommonComponents.GUI_DONE,
                        b -> this.onClose()
                ).pos(center - 100, y).width(98).build()
        );

        this.addRenderableWidget(
                net.minecraft.client.gui.components.Button.builder(
                        TAKE_BOOK,
                        b -> this.sendButtonClick(DisplayLecternMenu.BUTTON_TAKE_BOOK)
                ).pos(center + 2, y).width(98).build()
        );
    }

    @Override
    protected void pageBack() {
        this.sendButtonClick(DisplayLecternMenu.BUTTON_PREV_PAGE);
    }

    @Override
    protected void pageForward() {
        this.sendButtonClick(DisplayLecternMenu.BUTTON_NEXT_PAGE);
    }

    @Override
    protected boolean forcePage(int page) {

        if (page != this.menu.getPage()) {

            this.sendButtonClick(100 + page);

            return true;
        }

        return false;
    }

    private void sendButtonClick(int id) {

        this.minecraft.gameMode.handleInventoryButtonClick(
                this.menu.containerId,
                id
        );
    }

    void bookChanged() {

        ItemStack stack = this.menu.getBook();

        this.setBookAccess(
                BookAccess.fromItem(stack) != null
                        ? BookAccess.fromItem(stack)
                        : EMPTY_ACCESS
        );
    }

    void pageChanged() {

        this.setPage(this.menu.getPage());
    }

    @Override
    protected void closeContainerOnServer() {

        this.minecraft.player.closeContainer();
    }

    @Override
    public boolean isPauseScreen() {

        return false;
    }
}