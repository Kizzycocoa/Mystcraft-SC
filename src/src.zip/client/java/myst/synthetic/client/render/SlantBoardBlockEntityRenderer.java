package myst.synthetic.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import myst.synthetic.block.BlockSlantBoard;
import myst.synthetic.block.entity.BlockEntitySlantBoard;
import myst.synthetic.client.render.model.ObjMesh;
import myst.synthetic.client.render.model.ObjMeshLoader;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class SlantBoardBlockEntityRenderer
        implements BlockEntityRenderer<BlockEntitySlantBoard, SlantBoardRenderState> {

    private static final ObjMesh MODEL = ObjMeshLoader.load(
            Identifier.fromNamespaceAndPath("mystcraft-sc", "models/block/slant_board.obj")
    );

    public SlantBoardBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public SlantBoardRenderState createRenderState() {
        return new SlantBoardRenderState();
    }

    @Override
    public void extractRenderState(
            BlockEntitySlantBoard blockEntity,
            SlantBoardRenderState state,
            float tickProgress,
            Vec3 cameraPos,
            @Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay
    ) {
        BlockEntityRenderer.super.extractRenderState(blockEntity, state, tickProgress, cameraPos, crumblingOverlay);

        state.facing = blockEntity.getBlockState().getValue(BlockSlantBoard.FACING);
        state.wood = blockEntity.getBlockState().getValue(BlockSlantBoard.WOOD);

        if (blockEntity.getLevel() != null) {
            var level = blockEntity.getLevel();
            var pos = blockEntity.getBlockPos();

            state.selfLight = LevelRenderer.getLightColor(level, pos);
            state.northLight = LevelRenderer.getLightColor(level, pos.north());
            state.southLight = LevelRenderer.getLightColor(level, pos.south());
            state.eastLight = LevelRenderer.getLightColor(level, pos.east());
            state.westLight = LevelRenderer.getLightColor(level, pos.west());
            state.downLight = LevelRenderer.getLightColor(level, pos.below());
        } else {
            state.selfLight = 15728880;
            state.northLight = 15728880;
            state.southLight = 15728880;
            state.eastLight = 15728880;
            state.westLight = 15728880;
            state.downLight = 15728880;
        }
    }

    private static float[] averageNormal(ObjMesh.Face face) {
        float x = 0.0F;
        float y = 0.0F;
        float z = 0.0F;

        for (ObjMesh.FaceVertex fv : face.vertices()) {
            float[] n = MODEL.getNormal(fv.normalIndex());
            x += n[0];
            y += n[1];
            z += n[2];
        }

        float length = (float)Math.sqrt(x * x + y * y + z * z);
        if (length == 0.0F) {
            return new float[] {0.0F, 1.0F, 0.0F};
        }

        return new float[] {x / length, y / length, z / length};
    }

    private static float[] rotateNormal(float[] normal, Direction facing) {
        float nx = normal[0];
        float ny = normal[1];
        float nz = normal[2];

        switch (facing) {
            case NORTH -> {
                // no change
            }
            case SOUTH -> {
                nx = -nx;
                nz = -nz;
            }
            case WEST -> {
                float oldNx = nx;
                nx = nz;
                nz = -oldNx;
            }
            case EAST -> {
                float oldNx = nx;
                nx = -nz;
                nz = oldNx;
            }
        }

        return new float[] { nx, ny, nz };
    }

    private static int resolveFaceLight(ObjMesh.Face face, SlantBoardRenderState state) {
        float[] localNormal = averageNormal(face);
        float[] worldNormal = rotateNormal(localNormal, state.facing);

        float nx = worldNormal[0];
        float ny = worldNormal[1];
        float nz = worldNormal[2];

        // Brim:
        // only the single outer face should use neighbouring side light.
        // all other brim faces use the block's inner/self light.
        //
        // In this OBJ, the brim's outer face is local +Z.
        if ("brim".equals(face.objectName())) {
            if (localNormal[2] < -0.75F) {
                if (nz < -0.75F) {
                    return state.northLight;
                }
                if (nz > 0.75F) {
                    return state.southLight;
                }
                if (nx > 0.75F) {
                    return state.eastLight;
                }
                if (nx < -0.75F) {
                    return state.westLight;
                }
            }

            return state.selfLight;
        }

        // Base behavior stays as before.
        if (ny < -0.75F) {
            return state.downLight;
        }

        if (nz < -0.75F) {
            return state.northLight;
        }
        if (nz > 0.75F) {
            return state.southLight;
        }
        if (nx > 0.75F) {
            return state.eastLight;
        }
        if (nx < -0.75F) {
            return state.westLight;
        }

        return state.selfLight;
    }

    @Override
    public void submit(
            SlantBoardRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector queue,
            CameraRenderState cameraState
    ) {
        poseStack.pushPose();

        // Move render origin to the center of the block.
        poseStack.translate(0.5F, 0.0F, 0.5F);

        // Rotate around the block center.
        rotateFromFacing(poseStack, state.facing);

        // Scale the raw OBJ up to a 1x1x7/16 block footprint.
        poseStack.scale(1.1428572F, 1.4071103F, 1.0666667F);

        // Re-center and floor-align the raw OBJ mesh in its own local space.
        poseStack.translate(0.0F, -0.0063086664F, -0.03125F);

        SlantBoardRenderPipelines.submitWorld(
                queue,
                poseStack,
                state.wood,
                face -> resolveFaceLight(face, state),
                MODEL
        );

        poseStack.popPose();
    }

    private static void rotateFromFacing(PoseStack poseStack, Direction facing) {
        switch (facing) {
            case EAST -> poseStack.mulPose(Axis.YP.rotationDegrees(270.0F));
            case SOUTH -> poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
            case WEST -> poseStack.mulPose(Axis.YP.rotationDegrees(90.0F));
        }
    }
}