package myst.synthetic.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import myst.synthetic.block.BlockBookstand;
import myst.synthetic.block.entity.BlockEntityBookstand;
import myst.synthetic.client.render.model.ObjMesh;
import myst.synthetic.client.render.model.ObjMeshLoader;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class BookstandBlockEntityRenderer
        implements BlockEntityRenderer<BlockEntityBookstand, BookstandRenderState> {

    private static final ObjMesh MODEL = ObjMeshLoader.load(
            Identifier.fromNamespaceAndPath("mystcraft-sc", "models/block/bookstand.obj")
    );

    private final ItemModelResolver itemModelResolver;

    public BookstandBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        this.itemModelResolver = context.itemModelResolver();
    }

    @Override
    public BookstandRenderState createRenderState() {
        return new BookstandRenderState();
    }

    @Override
    public void extractRenderState(
            BlockEntityBookstand blockEntity,
            BookstandRenderState state,
            float tickProgress,
            Vec3 cameraPos,
            @Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay
    ) {
        BlockEntityRenderer.super.extractRenderState(blockEntity, state, tickProgress, cameraPos, crumblingOverlay);

        state.rotationIndex = blockEntity.getBlockState().getValue(BlockBookstand.ROTATION_INDEX);
        state.wood = blockEntity.getBlockState().getValue(BlockBookstand.WOOD);
        state.contentType = blockEntity.getContentType();

        ItemStack stored = blockEntity.getStoredItem();
        state.displayedStack = stored.copy();
        state.hasDisplayItem = !stored.isEmpty();

        if (blockEntity.getLevel() != null) {
            state.packedLight = LevelRenderer.getLightColor(blockEntity.getLevel(), blockEntity.getBlockPos());

            DisplayItemRenderHelper.prepareTopItem(
                    this.itemModelResolver,
                    state.displayedItem,
                    stored,
                    blockEntity.getLevel()
            );
        } else {
            state.packedLight = 0;
            state.displayedItem.clear();
        }
    }

    @Override
    public void submit(
            BookstandRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector queue,
            CameraRenderState cameraState
    ) {
        poseStack.pushPose();

        poseStack.translate(0.5F, 0.0F, 0.5F);
        poseStack.mulPose(Axis.YP.rotationDegrees(-45.0F * state.rotationIndex));

        BookstandRenderPipelines.submitWorld(
                queue,
                poseStack,
                state.wood,
                face -> state.packedLight,
                MODEL
        );

        if (state.hasDisplayItem) {
            poseStack.pushPose();

            // Legacy bookstand put the displayed book slightly above the top plate,
            // rotated to sit across it. This keeps the same broad placement.
            poseStack.translate(0.0F, 0.74F, 0.0F);

            if (DisplayItemRenderHelper.isBookLike(state.contentType)) {
                poseStack.mulPose(Axis.YP.rotationDegrees(90.0F));
                poseStack.mulPose(Axis.ZP.rotationDegrees(120.0F));
                poseStack.scale(0.8F, 0.8F, 0.8F);
            } else {
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
                poseStack.scale(0.5F, 0.5F, 0.5F);
            }

            DisplayItemRenderHelper.submitPreparedItem(
                    state.displayedItem,
                    poseStack,
                    queue,
                    state.packedLight
            );

            poseStack.popPose();
        }

        poseStack.popPose();
    }
}