package myst.synthetic.client.render.model;

import net.minecraft.resources.Identifier;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public final class ObjMeshLoader {

    public static ObjMesh load(Identifier id) {
        try {
            var stream = ObjMeshLoader.class
                    .getResourceAsStream("/assets/" + id.getNamespace()
                            + "/" + id.getPath());

            if (stream == null) {
                throw new RuntimeException("OBJ not found: " + id);
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));

            List<float[]> vertices = new ArrayList<>();
            List<int[]> faces = new ArrayList<>();

            reader.lines().forEach(line -> {

                if (line.startsWith("v ")) {

                    String[] parts = line.split(" ");

                    vertices.add(new float[]{
                            Float.parseFloat(parts[1]),
                            Float.parseFloat(parts[2]),
                            Float.parseFloat(parts[3])
                    });

                }

                if (line.startsWith("f ")) {

                    String[] parts = line.split(" ");

                    faces.add(new int[]{
                            Integer.parseInt(parts[1].split("/")[0]) - 1,
                            Integer.parseInt(parts[2].split("/")[0]) - 1,
                            Integer.parseInt(parts[3].split("/")[0]) - 1,
                            Integer.parseInt(parts[4].split("/")[0]) - 1
                    });

                }

            });

            return new ObjMesh(vertices, faces);

        } catch (Exception e) {

            throw new RuntimeException("Failed to load OBJ: " + id, e);

        }
    }

}