package myst.synthetic.client.render.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;

import java.util.List;

public final class ObjMesh {

    private final List<float[]> vertices;
    private final List<int[]> faces;

    public ObjMesh(List<float[]> vertices, List<int[]> faces) {
        this.vertices = vertices;
        this.faces = faces;
    }

    public void render(
            PoseStack poseStack,
            MultiBufferSource buffers,
            Identifier texture,
            int light,
            int overlay
    ) {
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutout(texture));
        var pose = poseStack.last();

        for (int[] face : faces) {
            for (int index : face) {
                float[] v = vertices.get(index);

                consumer.addVertex(
                                pose.pose(),
                                v[0],
                                v[1],
                                v[2]
                        )
                        .setUv(0, 0)
                        .setLight(light)
                        .setOverlay(overlay);
            }
        }
    }
}